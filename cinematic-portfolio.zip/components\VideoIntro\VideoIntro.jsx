"use client";

import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import CinematicLayer from "../CinematicLayer/CinematicLayer";
import styles from "./VideoIntro.module.css";

const VIDEO_SRC = "/videos/hero.mp4";

export default function VideoIntro() {
  const foregroundRef = useRef(null);
  const ambientRef = useRef(null);
  const heroRef = useRef(null);
  const soundHintTimeout = useRef(null);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [showSoundHint, setShowSoundHint] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);

  // Entrance animation ------------------------------------------------
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        defaults: {
          ease: "power3.out",
          duration: prefersReducedMotion ? 0.01 : 1.1,
        },
      });

      tl.fromTo(
        heroRef.current,
        { opacity: 0 },
        { opacity: 1, duration: prefersReducedMotion ? 0.01 : 1.4 }
      )
        .fromTo(
          `.${styles.eyebrow}`,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0 },
          "-=0.9"
        )
        .fromTo(
          `.${styles.nameLine}`,
          { opacity: 0, y: 46 },
          { opacity: 1, y: 0, stagger: 0.14 },
          "-=0.6"
        )
        .fromTo(
          `.${styles.role}`,
          { opacity: 0, y: 18 },
          { opacity: 1, y: 0 },
          "-=0.5"
        )
        .fromTo(
          `.${styles.controls}`,
          { opacity: 0 },
          { opacity: 1, duration: 0.6 },
          "-=0.4"
        )
        .fromTo(
          `.${styles.scrollIndicator}`,
          { opacity: 0 },
          { opacity: 1, duration: 0.6 },
          "-=0.3"
        );
    }, heroRef);

    return () => ctx.revert();
  }, []);

  // Auto-hide the "tap for sound" badge --------------------------------
  useEffect(() => {
    soundHintTimeout.current = setTimeout(() => {
      setShowSoundHint(false);
    }, 4500);
    return () => clearTimeout(soundHintTimeout.current);
  }, []);

  function togglePlayback() {
    const fg = foregroundRef.current;
    if (!fg) return;

    if (fg.paused) {
      fg.play();
      setIsPlaying(true);
    } else {
      fg.pause();
      setIsPlaying(false);
    }
  }

  function toggleMute() {
    const fg = foregroundRef.current;
    if (!fg) return;
    const nextMuted = !fg.muted;
    fg.muted = nextMuted;
    setIsMuted(nextMuted);
    setShowSoundHint(false);
  }

  function scrollToNext() {
    const next = document.getElementById("work");
    next?.scrollIntoView({ behavior: "smooth" });
  }

  return (
    <section
      ref={heroRef}
      className={styles.hero}
      aria-label="Introduction"
    >
      {/* Full-bleed ambient blur background */}
      <div className={styles.ambientLayer}>
        <video
          className={styles.ambientVideo}
          src={VIDEO_SRC}
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          aria-hidden="true"
          tabIndex={-1}
        />
      </div>

      {/* Sharp video — right half */}
      <div className={styles.videoLayer}>
        <video
          ref={foregroundRef}
          className={styles.foregroundVideo}
          src={VIDEO_SRC}
          autoPlay
          loop
          muted={isMuted}
          playsInline
          preload="auto"
          onLoadedData={() => setIsLoaded(true)}
        />
      </div>

      <div className={styles.gradientOverlay} />
      <CinematicLayer />

      <div className={styles.content}>
        <p className={styles.eyebrow}>AI &amp; ML Engineer &bull; Full Stack Developer</p>
        <h1 className={styles.name} aria-label="Shrishail Hiremath">
          <span className={styles.nameLine}>Shrishail</span>
          <span className={styles.nameLine}>Hiremath</span>
        </h1>
        <p className={styles.role}>
          Building AI-powered applications, modern web experiences,
          and scalable software solutions.
        </p>
      </div>

      <div
        className={`${styles.soundBadge} ${
          showSoundHint ? styles.soundBadgeVisible : ""
        }`}
      >
        Tap for sound
      </div>

      <div className={styles.controls}>
        <button
          type="button"
          className={styles.glassButton}
          onClick={togglePlayback}
          aria-label={isPlaying ? "Pause video" : "Play video"}
        >
          {isPlaying ? (
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <rect x="6" y="5" width="4" height="14" rx="1" />
              <rect x="14" y="5" width="4" height="14" rx="1" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M7 5.5v13a1 1 0 0 0 1.5.87l11-6.5a1 1 0 0 0 0-1.74l-11-6.5A1 1 0 0 0 7 5.5z" />
            </svg>
          )}
        </button>
        <button
          type="button"
          className={styles.glassButton}
          onClick={toggleMute}
          aria-label={isMuted ? "Unmute video" : "Mute video"}
        >
          {isMuted ? (
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M4 9v6h4l5 5V4L8 9H4z" />
              <path
                d="M16 8.5l5 7M21 8.5l-5 7"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
              />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M4 9v6h4l5 5V4L8 9H4z" />
              <path
                d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                fill="none"
              />
            </svg>
          )}
        </button>
      </div>

      <button
        type="button"
        className={styles.scrollIndicator}
        onClick={scrollToNext}
        aria-label="Scroll to next section"
      >
        <span className={styles.scrollLabel}>Scroll</span>
        <span className={styles.scrollLine} />
      </button>

      <span className={styles.srOnly} aria-live="polite">
        {isLoaded ? "" : "Loading intro video"}
      </span>
    </section>
  );
}
