import VideoIntro from "../components/VideoIntro/VideoIntro";
import Navbar from "../components/Navbar/Navbar";
import WorkSection from "../components/WorkSection/WorkSection";
import SkillsSection from "../components/SkillsSection/SkillsSection";
import AboutSection from "../components/AboutSection/AboutSection";
import Footer from "../components/Footer/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <VideoIntro />
      <WorkSection />
      <SkillsSection />
      <AboutSection />
      <Footer />
    </main>
  );
}
